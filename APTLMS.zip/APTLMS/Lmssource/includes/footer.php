<!--footer-->
<div class="footer">
  <!-- container -->
  <div class="container">
    <div class="col-md-6 footer-left">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="user/login.php">Student</a></li>
      </ul>
      </div>
      <div class="col-md-3 footer-middle">
        <?php
$sql="SELECT * from tblpage where PageType='contactus'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
  foreach($results as $row)
  {               ?>
        <h3>Address</h3>
        <div class="address">
          <p><?php  echo htmlentities($row->PageDescription);?>
          </p>
        </div>
        <div class="phone">
          <p><?php  echo htmlentities($row->MobileNumber);?></p>
        </div>
      <?php $cnt=$cnt+1;}} ?></div>
      <div class="col-md-3 footer-right">
        <h3>LMS</h3>
        <p style="align-self: justify ;">Our library offers collaborative learning and community interaction in a safe setting,
           with co-working spaces, study rooms, workstations, thousands of books, 
           and unlimited internet – all in one place. We aspire to offer experiences,
           generate ideas and discussion, and bring people and communities together in a vibrant social space.</p>
      </div>
      <div class="clearfix"> </div> 
    </div>
    <!-- //container -->
  </div>
<!--/footer-->
<!--copy-rights-->
<div class="copyright">
    <!-- container -->
    <div class="container">
      <div class="copyright-left">
      <p>© <?php echo date('Y');?> Library Management System </p>
      </div>
      <div class="copyright-right">
        <ul>
          <li><a href="https://twitter.com/SOOMROF1?t=qPDl6uKXTolycVORXRX8Q&s=09" class="twitter"> </a></li>
          <li><a href="https://www.facebook.com/profile.php?id=100092689151919&mibextid=ZbWKwl" class="twitter facebook"> </a></li>
          <li><a href="https://www.linkedin.com/in/m-faisal-soomro-5ba342247" class="twitter linkedin"> </a></li>
          <li><a href="https://www.pinterest.com/noorsoomro2006" class="twitter pinterest"> </a></li>
        </ul>
      </div>
      <div class="clearfix"> </div>
      
    </div>
    <!-- //container -->
    <!---->
<script type="text/javascript">
    $(document).ready(function() {
        /*
        var defaults = {
        containerID: 'toTop', // fading element id
        containerHoverID: 'toTopHover', // fading element hover id
        scrollSpeed: 1200,
        easingType: 'linear' 
        };
        */
    $().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!----> 
  </div>


  
</body>
</html>