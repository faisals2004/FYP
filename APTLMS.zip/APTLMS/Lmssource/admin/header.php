<!DOCTYPE html>
<html lang="en">
<head>
		<title>Library Mannagement System || ADMIN</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Bootstrap -->
			<link href="../adminassets/css/bootstrap.css" rel="stylesheet" media="screen">
			<link href="../adminassets/css/bootstrap-responsive.css" rel="stylesheet" media="screen">
			<link href="../adminassets/css/docs.css" rel="stylesheet" media="screen">
			<link href="../adminassets/css/diapo.css" rel="stylesheet" media="screen">
			<link href="../adminassets/css/font-awesome.css" rel="stylesheet" media="screen">
			<link rel="stylesheet" type="text/css" href="../adminassets/css/style.css" />
			<link rel="stylesheet" type="text/css" href="../adminassets/css/DT_bootstrap.css" />
			<link rel="stylesheet" type="text/css" media="print" href="../adminassets/css/print.css" />
	
	<!-- js -->			
    <script src="../adminassets/js/jquery-1.7.2.min.js"></script>
    <script src="../adminassets/js/bootstrap.js"></script>
	<script src="../adminassets/js/jquery.hoverdir.js"></script>
			
<script>
jQuery(document).ready(function() {
$(function(){
	$('.pix_diapo').diapo();
});
});
</script>	
	<noscript>
			<style>
				.da-thumbs li a div {
					top: 0px;
					left: -100%;
					-webkit-transition: all 0.3s ease;
					-moz-transition: all 0.3s ease-in-out;
					-o-transition: all 0.3s ease-in-out;
					-ms-transition: all 0.3s ease-in-out;
					transition: all 0.3s ease-in-out;
				}
				.da-thumbs li a:hover div{
					left: 0px;
				}
			</style>
		</noscript>		
		
	 <script type="text/javascript" charset="utf-8" language="javascript" src="../adminassets/js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../adminassets/js/DT_bootstrap.js"></script>
	<script type='text/javascript' src='../adminassets/scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='../adminassets/scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='../adminassets/scripts/diapo.js'></script>


<!--sa calendar-->	
		<script type="text/javascript" src="../adminassets/js/datepicker.js"></script>
        <link href="../adminassets/css/datepicker.css" rel="stylesheet" type="text/css" />

</head>
<body>


<?php include('includes/dbconnection.php'); ?>


	
</body>
</html>